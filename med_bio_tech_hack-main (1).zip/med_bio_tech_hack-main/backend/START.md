# 🚀 ИНСТРУКЦИЯ ПО ЗАПУСКУ СЕРВИСА

## 📋 ШАГ 1: Откройте терминал (PowerShell или CMD)

### Вариант A: Через проводник Windows
1. Откройте папку: `c:\Users\Админ\Новая папка\med_bio_tech_hack-1\backend`
2. Нажмите `Shift + Правый клик` на пустом месте
3. Выберите **"Открыть окно PowerShell здесь"** или **"Открыть в терминале"**

### Вариант B: Через поиск Windows
1. Нажмите `Win + R`
2. Введите `powershell` или `cmd`
3. Нажмите Enter
4. Перейдите в папку командой:
   ```powershell
   cd "c:\Users\Админ\Новая папка\med_bio_tech_hack-1\backend"
   ```

---

## 📋 ШАГ 2: Проверьте Python

**Вставьте эту команду в терминал и нажмите Enter:**

```powershell
py --version
```

**Ожидаемый результат:** `Python 3.x.x` (например, Python 3.13.5)

**Если ошибка:** Установите Python с https://www.python.org/

---

## 📋 ШАГ 3: Установите зависимости

**Вставьте эти команды по очереди (каждую команду отдельно, нажимайте Enter после каждой):**

### Команда 1: Основные зависимости
```powershell
py -m pip install Flask flask-cors python-dotenv requests beautifulsoup4 lxml --user
```

### Команда 2: Для работы с PubMed (обязательно!)
```powershell
py -m pip install biopython --user
```

### Команда 3: Для генерации DOCX (опционально, но рекомендуется)
```powershell
py -m pip install python-docx --user
```

**Примечание:** Если возникают ошибки с прокси, попробуйте:
```powershell
py -m pip install Flask flask-cors python-dotenv requests beautifulsoup4 lxml biopython python-docx --user --trusted-host pypi.org --trusted-host files.pythonhosted.org
```

---

## 📋 ШАГ 4: Проверьте установку зависимостей

**Вставьте эту команду:**

```powershell
py check_and_run.py
```

**Ожидаемый результат:**
```
============================================================
Проверка зависимостей...
============================================================
[OK] Flask
[OK] flask-cors
[OK] python-dotenv
[OK] requests
[OK] beautifulsoup4
[OK] biopython (опционально)
[OK] python-docx (опционально)
============================================================

[SUCCESS] Все обязательные зависимости установлены!

Запуск сервиса...
============================================================
```

---

## 📋 ШАГ 5: Запустите сервис

### Вариант A: Автоматический запуск (рекомендуется)
**Вставьте эту команду:**

```powershell
py check_and_run.py
```

### Вариант B: Прямой запуск
**Вставьте эту команду:**

```powershell
py app.py
```

### Вариант C: Через batch файл (Windows)
**Вставьте эту команду:**

```powershell
.\run.bat
```

---

## 📋 ШАГ 6: Откройте в браузере

После запуска вы увидите в терминале:
```
Starting server on http://127.0.0.1:8000
API health check at http://127.0.0.1:8000/api/health
```

**Откройте в браузере:**
- **Главная страница:** http://127.0.0.1:8000
- **Проверка API:** http://127.0.0.1:8000/api/health

---

## 🛑 ОСТАНОВКА СЕРВИСА

**В терминале нажмите:** `Ctrl + C`

---

## ❓ РЕШЕНИЕ ПРОБЛЕМ

### Проблема: "py не является внутренней или внешней командой"

**Решение:** Используйте `python` вместо `py`:
```powershell
python --version
python app.py
```

### Проблема: Ошибки установки пакетов

**Решение:** Попробуйте с флагами:
```powershell
py -m pip install --upgrade pip --user
py -m pip install Flask flask-cors python-dotenv requests beautifulsoup4 lxml biopython python-docx --user --trusted-host pypi.org --trusted-host files.pythonhosted.org
```

### Проблема: Порт 8000 занят

**Решение:** Измените порт в файле `.env`:
```
PORT=8001
```

Или убейте процесс на порту 8000:
```powershell
netstat -ano | findstr :8000
taskkill /PID <номер_процесса> /F
```

### Проблема: API ключ не загружается

**Решение:** Проверьте файл `.env` в папке `backend`:
```
NCBI_API_KEY=72feaa1f188b673920ae39c39985d2535608
NCBI_EMAIL=research@example.com
```

---

## 📝 БЫСТРЫЙ СТАРТ (все команды подряд)

**Скопируйте и вставьте все команды по очереди:**

```powershell
# Переход в папку backend
cd "c:\Users\Админ\Новая папка\med_bio_tech_hack-1\backend"

# Проверка Python
py --version

# Установка зависимостей
py -m pip install Flask flask-cors python-dotenv requests beautifulsoup4 lxml biopython python-docx --user

# Запуск сервиса
py app.py
```

---

## ✅ ПРОВЕРКА РАБОТЫ

После запуска откройте в браузере:
1. http://127.0.0.1:8000 - главная страница
2. http://127.0.0.1:8000/api/health - проверка API

Если видите JSON ответ `{"status": "OK"}` - всё работает! ✅

---

**Готово! Сервис запущен и готов к работе!** 🎉
