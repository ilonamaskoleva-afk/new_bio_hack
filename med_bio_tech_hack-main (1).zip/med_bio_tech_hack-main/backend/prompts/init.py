from .prompts import Prompts

__all__ = ['Prompts']
```

#### **backend/prompts/prompts.py**
class Prompts:
    
    SYSTEM_PROMPT = """Вы - эксперт по клинической фармакологии и дизайну исследований биоэквивалентности (BE).
Ваша задача - помогать проектировать BE-исследования согласно российским (Решение № 85) и международным (EMA, FDA, WHO) требованиям.

Вы должны:
- Анализировать фармакокинетические параметры
- Выбирать оптимальный дизайн исследования
- Рассчитывать объем выборки
- Генерировать структурированные синопсисы протоколов

Всегда обосновывайте свои решения и ссылайтесь на регуляторные документы."""

    LITERATURE_SEARCH_PROMPT = """На основе следующей информации о препарате, найдите и извлеките ключевые фармакокинетические параметры:

Препарат: {inn}
Лекарственная форма: {dosage_form}
Дозировка: {dosage}

Из предоставленных данных литературы извлеките:
1. Cmax (максимальная концентрация в плазме) - значение и единицы
2. AUC (площадь под кривой) - значение и единицы  
3. Tmax (время достижения Cmax) - значение и единицы
4. T½ (период полувыведения) - значение и единицы
5. CVintra (внутрисубъектная вариабельность) - значение в %

Данные из литературы:
{literature_data}

Ответьте в формате JSON:
{{
    "cmax": {{"value": число, "unit": "единица"}},
    "auc": {{"value": число, "unit": "единица"}},
    "tmax": {{"value": число, "unit": "единица"}},
    "t_half": {{"value": число, "unit": "единица"}},
    "cvintra": {{"value": число, "unit": "%"}},
    "sources": ["список источников"]
}}"""

    DESIGN_SELECTION_PROMPT = """Выберите оптимальный дизайн исследования биоэквивалентности на основе следующих данных:

Препарат: {inn}
CVintra: {cvintra}%
Режим приёма: {administration_mode}
RSABE требуется: {rsabe_needed}
Дополнительные требования: {additional_requirements}

Доступные дизайны:
1. 2×2 Cross-over (стандартные препараты, CVintra ≤ 30%)
2. 3-way Replicate (средневариабельные, CVintra 30-50%)
3. 4-way Replicate (высоковариабельные, CVintra > 50%, RSABE)
4. Параллельный (препараты длительного действия, T½ > большой период)

Выберите дизайн и обоснуйте выбор. Укажите:
- Название дизайна
- Минимальное количество субъектов
- Количество периодов
- Продолжительность washout периодов
- Обоснование выбора

Ответьте в формате JSON:
{{
    "design": "название дизайна",
    "min_subjects": число,
    "periods": число,
    "washout_duration": "описание",
    "rationale": "обоснование"
}}"""

    SAMPLE_SIZE_PROMPT = """Рассчитайте объем выборки для исследования биоэквивалентности:

Дизайн: {design}
CVintra: {cvintra}%
Мощность: 80%
Уровень значимости: 0.05
Ожидаемый drop-out: {dropout_rate}%

Используйте формулу для {design}:
- Для 2×2 cross-over: N = 2(Zα + Zβ)² × σ² / (ln θ₁)²
- Для replicate designs: корректируйте с учетом количества периодов

Где:
- Zα = 1.96 (для α = 0.05)
- Zβ = 0.842 (для мощности 80%)
- σ² = ln(CV² + 1) - внутрисубъектная дисперсия
- θ₁ = 0.8 - нижняя граница эквивалентности

Рассчитайте:
1. Базовый размер выборки
2. С учетом drop-out
3. Итоговый размер (округленный)

Ответьте в формате JSON с пошаговым расчетом:
{{
    "base_sample_size": число,
    "adjusted_for_dropout": число,
    "final_sample_size": число,
    "calculation_steps": "пошаговое объяснение"
}}"""

    REGULATORY_CHECK_PROMPT = """Проверьте соответствие дизайна исследования регуляторным требованиям:

Дизайн исследования:
{study_design}

Препарат: {inn}
CVintra: {cvintra}%
Размер выборки: {sample_size}

Проверьте соответствие:
1. Решению № 85 (Россия)
2. EMA Guidelines on Bioequivalence
3. FDA Bioequivalence Guidance
4. WHO Guidelines on Bioequivalence

Для каждого регулятора укажите:
- Соответствует ли дизайн требованиям (да/нет)
- Возможные риски или несоответствия
- Рекомендации по улучшению

Ответьте в формате JSON:
{{
    "russia_decision_85": {{"compliant": bool, "issues": [], "recommendations": []}},
    "ema": {{"compliant": bool, "issues": [], "recommendations": []}},
    "fda": {{"compliant": bool, "issues": [], "recommendations": []}},
    "who": {{"compliant": bool, "issues": [], "recommendations": []}}
}}"""

    SYNOPSIS_GENERATION_PROMPT = """Сгенерируйте полный структурированный синопсис протокола исследования биоэквивалентности:

Входные данные:
{input_data}

Фармакокинетические параметры:
{pk_parameters}

Дизайн исследования:
{study_design}

Размер выборки:
{sample_size}

Регуляторная проверка:
{regulatory_check}

Сгенерируйте синопсис, включающий все разделы:

1. ОБОСНОВАНИЕ ДИЗАЙНА ИССЛЕДОВАНИЯ
2. ЦЕЛИ И ЗАДАЧИ
3. ОПИСАНИЕ ИССЛЕДУЕМОЙ ПОПУЛЯЦИИ
4. КРИТЕРИИ ВКЛЮЧЕНИЯ И ИСКЛЮЧЕНИЯ
5. ДИЗАЙН ИССЛЕДОВАНИЯ (фазы, периоды, рандомизация)
6. БИОАНАЛИТИЧЕСКИЕ МЕТОДЫ
7. ВРЕМЕННАЯ СТРУКТУРА (таймпоинты)
8. PK-ПАРАМЕТРЫ И СТАТИСТИЧЕСКАЯ МЕТОДОЛОГИЯ
9. ПЛАН МОНИТОРИНГА БЕЗОПАСНОСТИ
10. РАСЧЁТ ОБЪЁМА ВЫБОРКИ С ПОЯСНЕНИЯМИ
11. БИБЛИОГРАФИЧЕСКИЙ СПИСОК

Используйте профессиональный медицинский язык. Все утверждения должны быть обоснованы."""

    @staticmethod
    def format_prompt(template: str, **kwargs) -> str:
        """Форматирует промпт с переданными параметрами"""
        return template.format(**kwargs)

---

#### **backend/app.py**
from rag.rag_pipeline import RAGPipeline

# Инициализация RAG (один раз при старте)
rag_pipeline = None

def get_rag_pipeline():
    global rag_pipeline
    if rag_pipeline is None:
        rag_pipeline = RAGPipeline()
    return rag_pipeline

@app.route('/api/design/select_with_rag', methods=['POST'])
def select_design_with_rag():
    """
    Выбор дизайна С ИСПОЛЬЗОВАНИЕМ RAG (улучшенная версия)
    """
    data = request.json
    
    try:
        rag = get_rag_pipeline()
        
        result = rag.design_recommendation_with_rag(
            inn=data.get('inn', ''),
            cvintra=data.get('cvintra', 0),
            administration_mode=data.get('administration_mode', 'fasted')
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"RAG design selection error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/ask', methods=['POST'])
def ask_question():
    """
    Новый endpoint: задать вопрос системе (с RAG)
    """
    data = request.json
    question = data.get('question', '')
    
    if not question:
        return jsonify({"error": "Question is required"}), 400
    
    try:
        rag = get_rag_pipeline()
        result = rag.answer_with_rag(question)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"RAG question error: {e}")
        return jsonify({"error": str(e)}), 500
```

---

## 📊 **Пример работы RAG**

### **Запрос без RAG:**
```
User: "Какой дизайн нужен для CV=35%?"
LLM: "Вероятно, 3-way replicate, но я не уверен..."
```

### **Запрос с RAG:**
```
User: "Какой дизайн нужен для CV=35%?"

RAG система:
1. Ищет в векторной БД похожие куски текста
2. Находит в "Решение №85":
   "При CV 30-50% применяется 3-way replicate design..."
3. Передает этот контекст в LLM

LLM: "Согласно Решению Совета Евразийской экономической комиссии №85 
     (раздел 4.2), для препаратов с внутрисубъектной вариабельностью 
     в диапазоне 30-50% рекомендуется использовать 3-way replicate дизайн.
     
     Обоснование: такой дизайн позволяет оценить вариабельность 
     референтного препарата и применить более гибкие критерии 
     биоэквивалентности."

---

#### **backend/outputs/.gitkeep**
```
# Пустой файл чтобы Git отслеживал папку
